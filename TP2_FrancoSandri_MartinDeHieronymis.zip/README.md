# TP2_Paradigmas

## Para corre los ejs:
-Pararse en la carpeta build: 

    cd ej1/build

-Construir el CMake:

    cmake ..

-Compilar con make:

    make

-Correr ejecutable:

    ./ej1
